"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import Link from "next/link";
import { GameEvent, Team } from "@/lib/types";
import {
  getEvents,
  getAllResponses,
  getPlayersForTeam,
  getTeams,
} from "@/lib/store";

function getToday(): string {
  const d = new Date();
  return (
    d.getFullYear() +
    "-" +
    String(d.getMonth() + 1).padStart(2, "0") +
    "-" +
    String(d.getDate()).padStart(2, "0")
  );
}

/** Map Sunday → previous Saturday for weekend grouping */
function getWeekendKey(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  if (d.getDay() === 0) {
    d.setDate(d.getDate() - 1);
  }
  return d.toISOString().split("T")[0];
}

function formatDayHeading(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-IE", {
    weekday: "long",
    day: "numeric",
    month: "short",
  });
}

function formatWeekendLabel(dates: string[]): string {
  const sorted = [...new Set(dates)].sort();
  if (sorted.length === 0) return "";
  const first = new Date(sorted[0] + "T00:00:00");
  if (sorted.length === 1) {
    return first.toLocaleDateString("en-IE", {
      weekday: "short",
      day: "numeric",
      month: "short",
    });
  }
  const last = new Date(sorted[sorted.length - 1] + "T00:00:00");
  if (first.getMonth() === last.getMonth()) {
    return `${first.toLocaleDateString("en-IE", { day: "numeric" })}–${last.toLocaleDateString("en-IE", { day: "numeric", month: "short" })}`;
  }
  return `${first.toLocaleDateString("en-IE", { day: "numeric", month: "short" })} – ${last.toLocaleDateString("en-IE", { day: "numeric", month: "short" })}`;
}

type MatchWithTeam = GameEvent & { team: Team };

type WeekendGroup = {
  key: string;
  dates: string[];
  events: MatchWithTeam[];
  firstDate: string;
};

export default function HomePage() {
  const [weekends, setWeekends] = useState<WeekendGroup[]>([]);
  const [availCounts, setAvailCounts] = useState<
    Map<string, { available: number; total: number }>
  >(new Map());
  const [mounted, setMounted] = useState(false);
  const [installable, setInstallable] = useState(false);
  const [isIos, setIsIos] = useState(false);
  const [showIosHint, setShowIosHint] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const deferredPrompt = useRef<any>(null);

  const refresh = useCallback(() => {
    const teams = getTeams();
    const teamMap = new Map(teams.map((t) => [t.id, t]));
    const today = getToday();
    const allEvents = getEvents()
      .filter((e) => e.type === "match" && e.date >= today)
      .sort((a, b) => a.date.localeCompare(b.date));

    // Group by weekend
    const weekendMap = new Map<string, WeekendGroup>();
    for (const event of allEvents) {
      const key = getWeekendKey(event.date);
      const team = teamMap.get(event.teamId);
      if (!team) continue;
      if (!weekendMap.has(key)) {
        weekendMap.set(key, {
          key,
          dates: [],
          events: [],
          firstDate: event.date,
        });
      }
      const group = weekendMap.get(key)!;
      if (!group.dates.includes(event.date)) group.dates.push(event.date);
      group.events.push({ ...event, team });
      if (event.date < group.firstDate) group.firstDate = event.date;
    }

    setWeekends(
      [...weekendMap.values()].sort((a, b) =>
        a.firstDate.localeCompare(b.firstDate)
      )
    );

    // Availability counts per event
    const responses = getAllResponses();
    const counts = new Map<string, { available: number; total: number }>();
    for (const event of allEvents) {
      const players = getPlayersForTeam(event.teamId);
      const avail = players.filter((p) =>
        responses.some(
          (r) =>
            r.eventId === event.id &&
            r.playerId === p.id &&
            r.status === "available"
        )
      ).length;
      counts.set(event.id, { available: avail, total: players.length });
    }
    setAvailCounts(counts);
  }, []);

  useEffect(() => {
    refresh();
    setMounted(true);
  }, [refresh]);

  useEffect(() => {
    const onSync = () => refresh();
    window.addEventListener("firestore-sync", onSync);
    return () => {
      window.removeEventListener("firestore-sync", onSync);
    };
  }, [refresh]);

  // PWA install prompt
  useEffect(() => {
    // Already running as installed app?
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in window.navigator && (window.navigator as unknown as { standalone: boolean }).standalone);
    setIsStandalone(!!standalone);

    // iOS detection
    const ua = window.navigator.userAgent;
    const ios = /iPad|iPhone|iPod/.test(ua) || (ua.includes("Mac") && "ontouchend" in document);
    setIsIos(ios);

    // Android/Chrome install prompt
    const handler = (e: Event) => {
      e.preventDefault();
      deferredPrompt.current = e;
      setInstallable(true);
    };
    window.addEventListener("beforeinstallprompt", handler);

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt.current) {
      deferredPrompt.current.prompt();
      const result = await deferredPrompt.current.userChoice;
      if (result.outcome === "accepted") {
        setInstallable(false);
        setIsStandalone(true);
      }
      deferredPrompt.current = null;
    } else if (isIos) {
      setShowIosHint(true);
    }
  };

  if (!mounted) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="w-6 h-6 border-2 border-pitch-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (weekends.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center animate-fade-in"
        style={{ height: "calc(100dvh - 8rem)" }}
      >
        <p className="text-4xl mb-3">🏟️</p>
        <p className="text-slate-500 font-medium">No upcoming fixtures</p>
        <p className="text-slate-400 text-sm mt-1">
          The season hasn&apos;t started yet
        </p>
      </div>
    );
  }

  const nextWeekend = weekends[0];

  // Group next weekend's events by date
  const byDate = new Map<string, MatchWithTeam[]>();
  for (const event of nextWeekend.events) {
    if (!byDate.has(event.date)) byDate.set(event.date, []);
    byDate.get(event.date)!.push(event);
  }
  const sortedDates = [...byDate.keys()].sort();

  return (
    <div
      className="flex flex-col animate-fade-in -mb-4"
      style={{ height: "calc(100dvh - 8.5rem)" }}
    >
      {/* ── Header ── */}
      <div className="mb-3">
        <h2 className="text-lg font-bold text-slate-900">Upcoming Matches</h2>
        <p className="text-xs text-slate-500">
          {formatWeekendLabel(nextWeekend.dates)}
          {nextWeekend.events.length > 1 &&
            ` · ${nextWeekend.events.length} matches`}
        </p>
      </div>

      {/* ── Match cards — fills available space ── */}
      <div className="flex-1 flex flex-col gap-3 min-h-0">
        {sortedDates.map((date) => {
          const dayEvents = byDate.get(date)!;
          const sameDayClash = dayEvents.length > 1;
          return (
            <div key={date} className="flex flex-col gap-2">
              {/* Day heading */}
              <div className="flex items-center gap-2">
                <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  {formatDayHeading(date)}
                </h3>
                {sameDayClash && (
                  <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                    ⚡ {dayEvents.length} teams
                  </span>
                )}
              </div>

              {/* Cards */}
              {dayEvents.map((event) => {
                const counts = availCounts.get(event.id) || {
                  available: 0,
                  total: 0,
                };
                const pct =
                  counts.total > 0
                    ? (counts.available / counts.total) * 100
                    : 0;
                return (
                  <Link
                    key={event.id}
                    href={`/event/${event.id}`}
                    className="block bg-white rounded-xl shadow-card px-3.5 py-3 active:shadow-card-hover active:scale-[0.99] transition-all"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div>
                        <span className="text-[10px] font-bold text-pitch-600 uppercase tracking-wider">
                          {event.team.division}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">
                          vs {event.opponent}
                        </h4>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          event.homeAway === "H"
                            ? "bg-pitch-50 text-pitch-700"
                            : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        {event.homeAway === "H" ? "HOME" : "AWAY"}
                      </span>
                    </div>

                    {/* Availability bar */}
                    <div className="flex items-center gap-2.5">
                      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${Math.max(pct, counts.available > 0 ? 4 : 0)}%`,
                            backgroundColor:
                              counts.available === 0
                                ? "transparent"
                                : pct < 50
                                ? "#ef4444"
                                : pct < 75
                                ? "#f59e0b"
                                : "#1e3a6e",
                          }}
                        />
                      </div>
                      <span
                        className={`text-[11px] font-bold tabular-nums ${
                          counts.available === 0
                            ? "text-slate-300"
                            : "text-slate-600"
                        }`}
                      >
                        {counts.available}/{counts.total}
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* ── Bottom actions — pinned to bottom ── */}
      <div className="pt-3 mt-auto flex flex-col gap-2">
        <Link
          href="/squad"
          className="block text-center py-3 rounded-xl bg-pitch-600 text-white text-sm font-bold active:bg-pitch-700 transition-colors shadow-md"
        >
          Mark Availability
        </Link>

        {/* Install app — hidden when already installed */}
        {!isStandalone && (installable || isIos) && (
          <button
            onClick={handleInstall}
            className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white shadow-card text-xs font-semibold text-slate-500 active:bg-gray-50 transition-colors"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Download App
          </button>
        )}
      </div>

      {/* iOS install instructions overlay */}
      {showIosHint && (
        <div
          className="fixed inset-0 z-[100] bg-black/50 flex items-end justify-center"
          onClick={() => setShowIosHint(false)}
        >
          <div
            className="bg-white rounded-t-2xl w-full max-w-lg p-6 pb-10 animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900">
                Install Cluichí
              </h3>
              <button
                onClick={() => setShowIosHint(false)}
                className="text-slate-400 active:text-slate-600 p-1"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="w-7 h-7 rounded-full bg-pitch-50 text-pitch-600 flex items-center justify-center text-xs font-bold shrink-0">1</span>
                <p className="text-sm text-slate-600 pt-0.5">
                  Tap the <strong>Share</strong> button
                  <span className="inline-block mx-1 align-middle">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
                      <polyline points="16 6 12 2 8 6" />
                      <line x1="12" y1="2" x2="12" y2="15" />
                    </svg>
                  </span>
                  at the bottom of Safari
                </p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-7 h-7 rounded-full bg-pitch-50 text-pitch-600 flex items-center justify-center text-xs font-bold shrink-0">2</span>
                <p className="text-sm text-slate-600 pt-0.5">
                  Scroll down and tap <strong>Add to Home Screen</strong>
                </p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-7 h-7 rounded-full bg-pitch-50 text-pitch-600 flex items-center justify-center text-xs font-bold shrink-0">3</span>
                <p className="text-sm text-slate-600 pt-0.5">
                  Tap <strong>Add</strong> — Cluichí appears as an app on your home screen
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
