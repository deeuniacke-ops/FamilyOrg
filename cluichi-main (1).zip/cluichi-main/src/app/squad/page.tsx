"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { GameEvent, Player, Team } from "@/lib/types";
import {
  getEventsForTeam,
  getAllResponses,
  getPlayersForTeam,
  getTeams,
  getActiveTeamId,
  setActiveTeamId,
  cycleAvailability,
} from "@/lib/store";

function formatDateShort(dateStr: string): string {
  const date = new Date(dateStr + "T00:00:00");
  return date
    .toLocaleDateString("en-IE", {
      weekday: "short",
      day: "numeric",
      month: "short",
    })
    .toUpperCase();
}

function StatusCell({
  status,
  onTap,
}: {
  status: "available" | "unavailable" | "maybe" | null;
  onTap: () => void;
}) {
  return (
    <button
      onClick={onTap}
      className="w-9 h-9 rounded-full flex items-center justify-center mx-auto active:scale-90 transition-transform duration-100 select-none"
      style={{
        backgroundColor:
          status === "available"
            ? "#16a34a"
            : status === "unavailable"
            ? "#dc2626"
            : status === "maybe"
            ? "#f59e0b"
            : "#e5e7eb",
      }}
    >
      {status === "available" && (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12" />
        </svg>
      )}
      {status === "unavailable" && (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      )}
      {status === "maybe" && (
        <span className="text-white text-xs font-bold">?</span>
      )}
      {status === null && (
        <span className="text-slate-400 text-sm">—</span>
      )}
    </button>
  );
}

function getToday(): string {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

export default function SquadPage() {
  const [events, setEvents] = useState<GameEvent[]>([]);
  const [pastEvents, setPastEvents] = useState<GameEvent[]>([]);
  const [showPast, setShowPast] = useState(false);
  const [responseMap, setResponseMap] = useState<Map<string, "available" | "unavailable" | "maybe">>(new Map());
  const [players, setPlayerList] = useState<Player[]>([]);
  const [teams, setTeamsList] = useState<Team[]>([]);
  const [activeTeamId, setActiveTeam] = useState("");
  const [mounted, setMounted] = useState(false);

  const refresh = useCallback(
    (teamId?: string) => {
      const tid = teamId || activeTeamId || getActiveTeamId();
      const allMatches = getEventsForTeam(tid).filter((e) => e.type === "match");
      const today = getToday();
      setEvents(allMatches.filter((e) => e.date >= today));
      setPastEvents(allMatches.filter((e) => e.date < today));
      const allResponses = getAllResponses();
      const rMap = new Map<string, "available" | "unavailable" | "maybe">();
      for (const r of allResponses) {
        if (r.status) rMap.set(`${r.eventId}-${r.playerId}`, r.status);
      }
      setResponseMap(rMap);
      setPlayerList(
        getPlayersForTeam(tid).sort((a, b) => a.name.localeCompare(b.name))
      );
      setTeamsList(getTeams());
      setActiveTeam(tid);
    },
    [activeTeamId]
  );

  useEffect(() => {
    refresh();
    setMounted(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-render when Firestore syncs new data from other users
  useEffect(() => {
    const onSync = () => refresh();
    window.addEventListener("firestore-sync", onSync);
    return () => window.removeEventListener("firestore-sync", onSync);
  }, [refresh]);

  const handleTeamChange = (teamId: string) => {
    setActiveTeamId(teamId);
    setActiveTeam(teamId);
    refresh(teamId);
  };

  const handleCellTap = (eventId: string, playerId: string) => {
    cycleAvailability(eventId, playerId);
    refresh();
  };

  if (!mounted) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="w-6 h-6 border-2 border-pitch-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const activeTeam = teams.find((t) => t.id === activeTeamId);

  // Available counts per event
  const availableCounts = new Map<string, number>();
  for (const event of events) {
    let count = 0;
    for (const player of players) {
      if (responseMap.get(`${event.id}-${player.id}`) === "available") count++;
    }
    availableCounts.set(event.id, count);
  }

  return (
    <div className="-mx-4 animate-fade-in">
      {/* Team selector */}
      <div className="px-4 mb-3">
        {teams.length > 1 && (
          <div className="flex gap-2 overflow-x-auto pb-2 mb-2 -mx-1 px-1 scrollbar-hide">
            {teams.map((team) => (
              <button
                key={team.id}
                onClick={() => handleTeamChange(team.id)}
                className={`shrink-0 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                  team.id === activeTeamId
                    ? "bg-pitch-600 text-white shadow-md"
                    : "bg-white text-slate-500 border border-gray-200 active:bg-gray-50"
                }`}
              >
                {team.division}
              </button>
            ))}
          </div>
        )}

        {activeTeam && (
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-pitch-500 to-pitch-700 flex items-center justify-center text-white font-bold text-xs">
              {activeTeam.shortName}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {activeTeam.name}
              </h2>
              <p className="text-[11px] text-slate-400">
                {activeTeam.division} · {activeTeam.season}
              </p>
            </div>
          </div>
        )}

        {/* Legend */}
        <div className="flex items-center gap-4 text-[11px] text-slate-500">
          <span className="flex items-center gap-1">
            <span className="w-4 h-4 rounded-full bg-green-600 inline-flex items-center justify-center">
              <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round"><polyline points="20 6 9 17 4 12" /></svg>
            </span>
            In
          </span>
          <span className="flex items-center gap-1">
            <span className="w-4 h-4 rounded-full bg-red-600 inline-flex items-center justify-center">
              <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
            </span>
            Out
          </span>
          <span className="flex items-center gap-1">
            <span className="w-4 h-4 rounded-full bg-gray-200 inline-flex items-center justify-center text-[8px] text-slate-400">—</span>
            Tap
          </span>
        </div>
      </div>

      {events.length === 0 && pastEvents.length === 0 ? (
        <div className="text-center py-16 px-4">
          <p className="text-4xl mb-3">🏟️</p>
          <p className="text-slate-500 font-medium">No fixtures yet</p>
          <p className="text-slate-400 text-sm mt-1">
            Create a match to get started
          </p>
        </div>
      ) : (
        <>
          {events.length === 0 ? (
            <div className="text-center py-8 px-4">
              <p className="text-slate-400 text-sm">No upcoming fixtures</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table
                className="w-full border-collapse"
                style={{ minWidth: `${90 + events.length * 56}px` }}
              >
                {/* Column headers — fixture dates */}
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="sticky left-0 z-20 bg-gray-50 text-left py-2 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 min-w-[90px]">
                      Player
                    </th>
                    {events.map((event) => (
                      <th key={event.id} className="py-1 px-0.5 text-center min-w-[52px]">
                        <Link href={`/event/${event.id}`} className="block">
                          <div className="text-[9px] text-slate-400 leading-tight whitespace-nowrap">
                            {formatDateShort(event.date)}
                          </div>
                          <div className="text-[11px] font-bold text-slate-700 mt-0.5">
                            {event.opponentShort || "—"}
                          </div>
                          <div className={`text-[9px] font-bold ${
                            event.homeAway === "H" ? "text-pitch-600" : "text-slate-400"
                          }`}>
                            {event.homeAway || "—"}
                          </div>
                          <div className="text-[9px] text-slate-400 mt-0.5">
                            {!event.time || event.time === "TBD" ? "TBD" : event.time}
                          </div>
                        </Link>
                      </th>
                    ))}
                  </tr>
                </thead>

                {/* Player rows */}
                <tbody>
                  {players.map((player, i) => {
                    const rowBg = i % 2 === 0 ? "white" : "rgb(249 250 251)";
                    return (
                      <tr
                        key={player.id}
                        className="border-b border-gray-100"
                        style={{ backgroundColor: rowBg }}
                      >
                        <td
                          className="sticky left-0 z-10 py-1.5 px-3 text-[13px] font-medium text-slate-700 whitespace-nowrap"
                          style={{ backgroundColor: rowBg }}
                        >
                          <span className="flex items-center gap-1">
                            {player.name}
                            {player.nominatedTeamIds?.includes(activeTeamId) && (
                              <span className="text-[9px] font-black text-amber-600 bg-amber-100 w-4 h-4 rounded-full inline-flex items-center justify-center" title="Nominated">N</span>
                            )}
                          </span>
                        </td>
                        {events.map((event) => {
                          const status = responseMap.get(`${event.id}-${player.id}`) ?? null;
                          return (
                            <td key={event.id} className="py-1 px-0.5 text-center">
                              <StatusCell
                                status={status}
                                onTap={() => handleCellTap(event.id, player.id)}
                              />
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>

                {/* Footer — available count */}
                <tfoot>
                  <tr className="border-t-2 border-gray-300" style={{ backgroundColor: "rgb(249 250 251)" }}>
                    <td
                      className="sticky left-0 z-10 py-2.5 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500"
                      style={{ backgroundColor: "rgb(249 250 251)" }}
                    >
                      Available
                    </td>
                    {events.map((event) => {
                      const count = availableCounts.get(event.id) ?? 0;
                      return (
                        <td key={event.id} className="py-2.5 px-0.5 text-center">
                          <span className={`text-sm font-bold ${
                            count === 0
                              ? "text-slate-300"
                              : count < 11
                              ? "text-red-500"
                              : "text-green-600"
                          }`}>
                            {count}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                </tfoot>
              </table>
            </div>
          )}

          {/* Past fixtures — collapsible */}
          {pastEvents.length > 0 && (
            <div className="px-4 mt-4">
              <button
                onClick={() => setShowPast(!showPast)}
                className="w-full flex items-center justify-between py-3 text-xs font-bold text-slate-400 active:text-slate-600"
              >
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-slate-300" />
                  {pastEvents.length} past fixture{pastEvents.length !== 1 ? "s" : ""}
                </span>
                <svg
                  width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
                  className={`transition-transform duration-200 ${showPast ? "rotate-180" : ""}`}
                >
                  <polyline points="6 9 12 15 18 9" />
                </svg>
              </button>
              {showPast && (
                <div className="bg-white rounded-2xl shadow-card divide-y divide-gray-50 animate-fade-in">
                  {pastEvents.map((event) => {
                    const avail = players.filter(
                      (p) => responseMap.get(`${event.id}-${p.id}`) === "available"
                    ).length;
                    return (
                      <Link
                        key={event.id}
                        href={`/event/${event.id}`}
                        className="flex items-center justify-between px-4 py-3 active:bg-gray-50"
                      >
                        <div>
                          <span className="text-sm font-medium text-slate-500">
                            {event.opponentShort || event.opponent || event.title}
                          </span>
                          <p className="text-[11px] text-slate-300 mt-0.5">
                            {formatDateShort(event.date)}
                            {event.homeAway ? ` · ${event.homeAway === "H" ? "Home" : "Away"}` : ""}
                          </p>
                        </div>
                        <span className="text-xs font-bold text-slate-400">
                          {avail} in
                        </span>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
