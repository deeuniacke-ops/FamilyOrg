"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { Player, GameEvent, Team } from "@/lib/types";
import { isAdmin } from "@/components/AuthGate";
import {
  getPlayersForTeam,
  addPlayer,
  updatePlayer,
  removePlayerFromTeam,
  getEventsForTeam,
  removeEvent,
  getTeams,
  setActiveTeamId,
  getActiveTeam,
  updateTeam,
  addTeam,
  removeTeam,
  resetData,
  getClubName,
  setClubName as setClubNameStore,
  getClubInstagram,
  setClubInstagram as setClubInstagramStore,
} from "@/lib/store";
import { CURRENT_USER_ID } from "@/lib/mock-data";

// ── Types ────────────────────────────────────────────────────

type Flow =
  | null
  | "add-player"
  | "rename-player"
  | "remove-player"
  | "nominate-players"
  | "add-match"
  | "remove-match"
  | "edit-division"
  | "add-division"
  | "delete-division"
  | "club-name"
  | "instagram"
  | "share";

// ── Shared Components ────────────────────────────────────────

function BackButton({ onBack }: { onBack: () => void }) {
  return (
    <button
      onClick={onBack}
      className="flex items-center gap-1 text-sm font-medium text-slate-500 active:text-slate-700 mb-4 -ml-1"
    >
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="15 18 9 12 15 6" />
      </svg>
      Back
    </button>
  );
}

function DivisionPicker({
  title,
  subtitle,
  teams,
  onPick,
  onBack,
}: {
  title: string;
  subtitle: string;
  teams: Team[];
  onPick: (teamId: string) => void;
  onBack: () => void;
}) {
  return (
    <div className="animate-fade-in">
      <BackButton onBack={onBack} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">{title}</h2>
      <p className="text-sm text-slate-400 mb-5">{subtitle}</p>

      <div className="bg-white rounded-2xl shadow-card overflow-hidden divide-y divide-gray-50">
        {teams.map((team) => (
          <button
            key={team.id}
            onClick={() => onPick(team.id)}
            className="w-full flex items-center gap-4 px-4 py-4 active:bg-gray-50 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pitch-500 to-pitch-700 flex items-center justify-center text-white font-bold text-xs shrink-0">
              {team.shortName}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800">{team.division}</p>
              <p className="text-xs text-slate-400 mt-0.5">{team.league} · {team.season}</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 shrink-0">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>
        ))}
      </div>
    </div>
  );
}

function DivisionBadge({ teams, teamId }: { teams: Team[]; teamId: string }) {
  const team = teams.find((t) => t.id === teamId);
  if (!team) return null;
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-pitch-700 bg-pitch-50 px-2.5 py-1 rounded-lg mb-4">
      <span className="w-4 h-4 rounded bg-gradient-to-br from-pitch-500 to-pitch-700 inline-flex items-center justify-center text-white text-[8px] font-bold">
        {team.shortName}
      </span>
      {team.division}
    </span>
  );
}

// ── Add Player Flow ──────────────────────────────────────────

function AddPlayerFlow({ teamId, teams, onDone }: { teamId: string; teams: Team[]; onDone: () => void }) {
  const [name, setName] = useState("");
  const [added, setAdded] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleAdd = () => {
    if (name.trim()) {
      addPlayer(name.trim(), teamId);
      setAdded((prev) => [...prev, name.trim()]);
      setName("");
      inputRef.current?.focus();
    }
  };

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Add Player</h2>
      <DivisionBadge teams={teams} teamId={teamId} />

      <div className="flex gap-2">
        <input
          ref={inputRef}
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="Player name"
          className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none text-sm"
        />
        <button
          onClick={handleAdd}
          disabled={!name.trim()}
          className="px-5 py-3 rounded-xl bg-pitch-600 text-white text-sm font-semibold disabled:opacity-30 active:bg-pitch-700"
        >
          Add
        </button>
      </div>

      {added.length > 0 && (
        <div className="mt-4">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Added ({added.length})
          </p>
          <div className="flex flex-wrap gap-1.5">
            {added.map((n, i) => (
              <span key={i} className="text-xs bg-pitch-50 text-pitch-700 px-2.5 py-1 rounded-full font-medium">
                {n}
              </span>
            ))}
          </div>
        </div>
      )}

      <p className="text-xs text-slate-400 mt-4">
        Keep typing and tapping Add for multiple players.
      </p>
    </div>
  );
}

// ── Rename Player Flow ───────────────────────────────────────

function RenamePlayerFlow({ teamId, teams, onDone }: { teamId: string; teams: Team[]; onDone: () => void }) {
  const [players, setPlayerList] = useState<Player[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [tempName, setTempName] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(() => {
    setPlayerList(getPlayersForTeam(teamId).sort((a, b) => a.name.localeCompare(b.name)));
  }, [teamId]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { inputRef.current?.focus(); }, [editing]);

  const save = () => {
    if (editing && tempName.trim()) {
      updatePlayer(editing, { name: tempName.trim() });
      refresh();
    }
    setEditing(null);
  };

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Rename Player</h2>
      <DivisionBadge teams={teams} teamId={teamId} />

      <div className="bg-white rounded-xl overflow-hidden divide-y divide-gray-50">
        {players.map((p) => (
          <div key={p.id} className="flex items-center justify-between px-4 py-3">
            {editing === p.id ? (
              <input
                ref={inputRef}
                type="text"
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                onBlur={save}
                onKeyDown={(e) => e.key === "Enter" && save()}
                className="flex-1 text-sm font-medium text-slate-800 border-b-2 border-pitch-500 outline-none bg-transparent py-0.5 mr-2"
              />
            ) : (
              <span className="text-sm font-medium text-slate-700">{p.name}</span>
            )}
            {editing !== p.id && (
              <button
                onClick={() => { setEditing(p.id); setTempName(p.name); }}
                className="text-xs font-semibold text-pitch-600 active:opacity-60 px-2 py-1"
              >
                Rename
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Remove Player Flow ───────────────────────────────────────

function RemovePlayerFlow({ teamId, teams, onDone }: { teamId: string; teams: Team[]; onDone: () => void }) {
  const [players, setPlayerList] = useState<Player[]>([]);
  const [confirming, setConfirming] = useState<string | null>(null);

  const refresh = useCallback(() => {
    setPlayerList(getPlayersForTeam(teamId).sort((a, b) => a.name.localeCompare(b.name)));
  }, [teamId]);

  useEffect(() => { refresh(); }, [refresh]);

  // Stay in sync when Firestore updates (e.g. after batch delete)
  useEffect(() => {
    const onSync = () => refresh();
    window.addEventListener("firestore-sync", onSync);
    return () => window.removeEventListener("firestore-sync", onSync);
  }, [refresh]);

  const handleRemove = async (id: string) => {
    await removePlayerFromTeam(id, teamId);
    setConfirming(null);
    refresh();
  };

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Remove Player</h2>
      <DivisionBadge teams={teams} teamId={teamId} />

      <div className="bg-white rounded-xl overflow-hidden divide-y divide-gray-50">
        {players.map((p) => (
          <div key={p.id} className="flex items-center justify-between px-4 py-3">
            <span className="text-sm font-medium text-slate-700">
              {p.name}
              {p.id === CURRENT_USER_ID && (
                <span className="ml-1.5 text-[10px] text-pitch-600 bg-pitch-50 px-1.5 py-0.5 rounded-full font-semibold">You</span>
              )}
            </span>
            {p.id !== CURRENT_USER_ID && (
              confirming === p.id ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleRemove(p.id)}
                    className="text-xs font-semibold text-white bg-red-500 px-3 py-1.5 rounded-lg active:bg-red-600"
                  >
                    Remove
                  </button>
                  <button
                    onClick={() => setConfirming(null)}
                    className="text-xs text-slate-400 px-2 py-1.5"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setConfirming(p.id)}
                  className="text-xs font-semibold text-red-400 active:text-red-600 px-2 py-1"
                >
                  Remove
                </button>
              )
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Nominate Players Flow ────────────────────────────────────

function isNominatedForTeam(player: Player, teamId: string): boolean {
  return player.nominatedTeamIds?.includes(teamId) ?? false;
}

function toggleNomination(player: Player, teamId: string): string[] {
  const current = player.nominatedTeamIds ?? [];
  if (current.includes(teamId)) return current.filter((id) => id !== teamId);
  return [...current, teamId];
}

function NominatePlayersFlow({ teamId, teams, onDone }: { teamId: string; teams: Team[]; onDone: () => void }) {
  const [players, setPlayerList] = useState<Player[]>([]);

  const refresh = useCallback(() => {
    setPlayerList(getPlayersForTeam(teamId).sort((a, b) => a.name.localeCompare(b.name)));
  }, [teamId]);

  useEffect(() => { refresh(); }, [refresh]);

  const toggle = (id: string) => {
    const player = players.find((p) => p.id === id);
    if (player) {
      updatePlayer(id, { nominatedTeamIds: toggleNomination(player, teamId) });
      refresh();
    }
  };

  const nominated = players.filter((p) => isNominatedForTeam(p, teamId));

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Nominate Players</h2>
      <DivisionBadge teams={teams} teamId={teamId} />
      <p className="text-sm text-slate-400 mb-4 -mt-2">
        {nominated.length}/{players.length} nominated
      </p>

      <div className="bg-white rounded-xl overflow-hidden divide-y divide-gray-50">
        {players.map((p) => {
          const isNom = isNominatedForTeam(p, teamId);
          return (
            <button
              key={p.id}
              onClick={() => toggle(p.id)}
              className="w-full flex items-center justify-between px-4 py-3.5 active:bg-gray-50 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                  isNom ? "bg-pitch-600 border-pitch-600" : "border-gray-300 bg-white"
                }`}>
                  {isNom && (
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  )}
                </div>
                <span className={`text-sm font-medium ${isNom ? "text-slate-800" : "text-slate-500"}`}>
                  {p.name}
                </span>
              </div>
              {isNom && (
                <span className="text-[10px] font-bold uppercase tracking-wide text-pitch-600 bg-pitch-50 px-2 py-0.5 rounded-full">
                  Nominated
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Remove Match Flow ────────────────────────────────────────

function RemoveMatchFlow({ teamId, teams, onDone }: { teamId: string; teams: Team[]; onDone: () => void }) {
  const [events, setEventList] = useState<GameEvent[]>([]);
  const [confirming, setConfirming] = useState<string | null>(null);

  const refresh = useCallback(() => {
    setEventList(getEventsForTeam(teamId));
  }, [teamId]);

  useEffect(() => { refresh(); }, [refresh]);

  const handleRemove = async (id: string) => {
    await removeEvent(id);
    setConfirming(null);
    refresh();
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + "T00:00:00");
    return date.toLocaleDateString("en-IE", { weekday: "short", day: "numeric", month: "short" });
  };

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Remove Match</h2>
      <DivisionBadge teams={teams} teamId={teamId} />

      {events.length === 0 ? (
        <p className="text-sm text-slate-400 text-center py-8">No fixtures to remove</p>
      ) : (
        <div className="bg-white rounded-xl overflow-hidden divide-y divide-gray-50">
          {events.map((e) => (
            <div key={e.id} className="flex items-center justify-between px-4 py-3">
              <div>
                <span className="text-sm font-medium text-slate-700">{e.title}</span>
                <p className="text-xs text-slate-400">{formatDate(e.date)}{e.homeAway ? ` · ${e.homeAway === "H" ? "Home" : "Away"}` : ""}</p>
              </div>
              {confirming === e.id ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleRemove(e.id)}
                    className="text-xs font-semibold text-white bg-red-500 px-3 py-1.5 rounded-lg active:bg-red-600"
                  >
                    Delete
                  </button>
                  <button
                    onClick={() => setConfirming(null)}
                    className="text-xs text-slate-400 px-2 py-1.5"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setConfirming(e.id)}
                  className="text-xs font-semibold text-red-400 active:text-red-600 px-2 py-1"
                >
                  Remove
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Edit Division Flow ───────────────────────────────────────

function EditDivisionFlow({ teamId, teams, onDone }: { teamId: string; teams: Team[]; onDone: () => void }) {
  const [team, setTeamData] = useState<Team | null>(null);
  const [field, setField] = useState<keyof Team | null>(null);
  const [temp, setTemp] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = teams.find((t) => t.id === teamId);
    if (t) setTeamData(t);
  }, [teamId, teams]);

  useEffect(() => { inputRef.current?.focus(); }, [field]);

  const save = () => {
    if (field && team && temp.trim()) {
      updateTeam(teamId, { [field]: temp.trim() });
      setTeamData({ ...team, [field]: temp.trim() });
    }
    setField(null);
  };

  if (!team) return null;

  const fields: { key: keyof Team; label: string }[] = [
    { key: "name", label: "Club Name" },
    { key: "shortName", label: "Short Name" },
    { key: "division", label: "Division" },
    { key: "league", label: "League" },
    { key: "season", label: "Season" },
  ];

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Edit Division</h2>
      <DivisionBadge teams={teams} teamId={teamId} />

      <div className="bg-white rounded-xl overflow-hidden divide-y divide-gray-50">
        {fields.map((f) => (
          <div key={f.key} className="px-4 py-3">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-slate-300">{f.label}</label>
            {field === f.key ? (
              <input
                ref={inputRef}
                type="text"
                value={temp}
                onChange={(e) => setTemp(e.target.value)}
                onBlur={save}
                onKeyDown={(e) => e.key === "Enter" && save()}
                className="w-full text-sm font-medium text-slate-800 border-b-2 border-pitch-500 outline-none bg-transparent py-0.5"
              />
            ) : (
              <button
                onClick={() => { setField(f.key); setTemp(team[f.key]); }}
                className="w-full text-left text-sm font-medium text-slate-700 flex items-center justify-between active:opacity-60"
              >
                {team[f.key]}
                <span className="text-xs text-pitch-600">Edit</span>
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Club Name Flow ───────────────────────────────────────────

function ClubNameFlow({ onDone }: { onDone: () => void }) {
  const [name, setName] = useState(() => getClubName());
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const save = () => {
    if (name.trim()) {
      setClubNameStore(name.trim());
      // Notify the header to update
      window.dispatchEvent(new Event("club-name-changed"));
      onDone();
    }
  };

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Club Name</h2>
      <p className="text-sm text-slate-400 mb-4">This appears in the header</p>

      <div className="flex gap-2">
        <input
          ref={inputRef}
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && save()}
          placeholder="e.g. Cork Wanderers"
          className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none text-sm"
        />
        <button
          onClick={save}
          disabled={!name.trim()}
          className="px-5 py-3 rounded-xl bg-pitch-600 text-white text-sm font-semibold disabled:opacity-30 active:bg-pitch-700"
        >
          Save
        </button>
      </div>
    </div>
  );
}

// ── Instagram Flow ──────────────────────────────────────────

function InstagramFlow({ onDone }: { onDone: () => void }) {
  const saved = getClubInstagram();
  const [editing, setEditing] = useState(!saved);
  const [url, setUrl] = useState(saved);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  const save = () => {
    setClubInstagramStore(url.trim());
    window.dispatchEvent(new Event("club-settings-changed"));
    setEditing(false);
  };

  const remove = () => {
    setClubInstagramStore("");
    window.dispatchEvent(new Event("club-settings-changed"));
    onDone();
  };

  // Extract handle for display
  const displayHandle = saved
    ? saved.replace(/https?:\/\/(www\.)?(instagram\.com|instagr\.am)\/?/i, "").replace(/\/+$/, "")
    : "";

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Instagram</h2>
      <p className="text-sm text-slate-400 mb-4">
        Link to your club&apos;s Instagram
      </p>

      {!editing && saved ? (
        <>
          {/* Clickable link */}
          <a
            href={saved}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 bg-white rounded-xl shadow-card px-4 py-4 active:bg-gray-50 transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400 flex items-center justify-center text-white text-lg shrink-0">
              📷
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800 truncate">
                {displayHandle ? `@${displayHandle}` : saved}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">Tap to open Instagram</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 shrink-0">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <polyline points="15 3 21 3 21 9" />
              <line x1="10" y1="14" x2="21" y2="3" />
            </svg>
          </a>

          {/* Edit / Remove */}
          <div className="flex items-center gap-4 mt-4">
            <button
              onClick={() => setEditing(true)}
              className="text-xs font-semibold text-pitch-600 active:opacity-60"
            >
              Edit link
            </button>
            <button
              onClick={remove}
              className="text-xs font-semibold text-red-400 active:text-red-600"
            >
              Remove
            </button>
          </div>
        </>
      ) : (
        <>
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && save()}
              placeholder="https://instagram.com/corkwanderers"
              className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none text-sm"
            />
            <button
              onClick={save}
              disabled={!url.trim()}
              className="px-5 py-3 rounded-xl bg-pitch-600 text-white text-sm font-semibold disabled:opacity-30 active:bg-pitch-700"
            >
              Save
            </button>
          </div>

          {saved && (
            <button
              onClick={() => setEditing(false)}
              className="mt-3 text-xs font-semibold text-slate-400 active:text-slate-600"
            >
              Cancel
            </button>
          )}

          <p className="text-xs text-slate-400 mt-4">
            Paste the full URL, e.g. https://instagram.com/yourclub
          </p>
        </>
      )}
    </div>
  );
}

// ── Share Flow ──────────────────────────────────────────────

function ShareFlow({ onDone }: { onDone: () => void }) {
  const APP_URL = "https://cluichi-ebon.vercel.app";
  const [copied, setCopied] = useState(false);

  const playerMessage = `Join us on Cluichí for availability and fixtures 🏑\n\nOpen the app: ${APP_URL}\nCode: wanderersplayer`;
  const adminMessage = `Manage Cork Wanderers on Cluichí 🏑\n\nOpen the app: ${APP_URL}\nAdmin code: wanderers2026`;

  const share = async (message: string) => {
    if (navigator.share) {
      try {
        await navigator.share({ text: message });
        return;
      } catch {}
    }
    // Fallback: open WhatsApp with the message
    window.open(
      `https://wa.me/?text=${encodeURIComponent(message)}`,
      "_blank"
    );
  };

  const copyLink = async (message: string) => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Share App</h2>
      <p className="text-sm text-slate-400 mb-5">
        Send teammates the link and code to join
      </p>

      {/* Player invite */}
      <div className="bg-white rounded-2xl shadow-card p-4 mb-3">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-pitch-50 flex items-center justify-center text-lg shrink-0">👥</div>
          <div>
            <p className="text-sm font-semibold text-slate-800">Invite Players</p>
            <p className="text-xs text-slate-400">They can mark availability</p>
          </div>
        </div>
        <div className="bg-gray-50 rounded-xl px-3 py-2.5 mb-3">
          <p className="text-xs text-slate-500 whitespace-pre-line">{playerMessage}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => share(playerMessage)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#25D366] text-white text-xs font-bold active:opacity-80"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Share
          </button>
          <button
            onClick={() => copyLink(playerMessage)}
            className="px-4 py-2.5 rounded-xl bg-gray-100 text-slate-600 text-xs font-bold active:bg-gray-200"
          >
            {copied ? "Copied ✓" : "Copy"}
          </button>
        </div>
      </div>

      {/* Admin invite */}
      <div className="bg-white rounded-2xl shadow-card p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-cw-red-light flex items-center justify-center text-lg shrink-0">🔑</div>
          <div>
            <p className="text-sm font-semibold text-slate-800">Invite Admins</p>
            <p className="text-xs text-slate-400">Full access including Manage</p>
          </div>
        </div>
        <div className="bg-gray-50 rounded-xl px-3 py-2.5 mb-3">
          <p className="text-xs text-slate-500 whitespace-pre-line">{adminMessage}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => share(adminMessage)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#25D366] text-white text-xs font-bold active:opacity-80"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Share
          </button>
          <button
            onClick={() => copyLink(adminMessage)}
            className="px-4 py-2.5 rounded-xl bg-gray-100 text-slate-600 text-xs font-bold active:bg-gray-200"
          >
            {copied ? "Copied ✓" : "Copy"}
          </button>
        </div>
      </div>

      <p className="text-xs text-slate-400 mt-4 text-center">
        On mobile, Share opens WhatsApp, iMessage and more
      </p>
    </div>
  );
}

// ── Delete Division Flow ─────────────────────────────────────

function DeleteDivisionFlow({ teamId, teams, onDone, onDeleted }: { teamId: string; teams: Team[]; onDone: () => void; onDeleted: () => void }) {
  const [confirmed, setConfirmed] = useState(false);
  const team = teams.find((t) => t.id === teamId);
  const playerCount = getPlayersForTeam(teamId).length;
  const fixtureCount = getEventsForTeam(teamId).length;

  const handleDelete = async () => {
    await removeTeam(teamId);
    onDeleted();
  };

  if (!team) return null;

  return (
    <div className="animate-fade-in">
      <BackButton onBack={onDone} />
      <h2 className="text-lg font-bold text-slate-900 mb-1">Delete Division</h2>
      <DivisionBadge teams={teams} teamId={teamId} />

      <div className="bg-white rounded-2xl shadow-card overflow-hidden p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center text-red-500 text-lg shrink-0">
            ⚠️
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-800">
              Delete {team.division}?
            </p>
            <p className="text-xs text-slate-400 mt-0.5">This cannot be undone</p>
          </div>
        </div>

        <div className="bg-red-50 rounded-xl p-3 mb-4 space-y-1">
          <p className="text-xs text-red-600 font-medium">This will permanently remove:</p>
          <p className="text-xs text-red-500">• {playerCount} player{playerCount !== 1 ? "s" : ""} from this division</p>
          <p className="text-xs text-red-500">• {fixtureCount} fixture{fixtureCount !== 1 ? "s" : ""} and all responses</p>
        </div>

        {!confirmed ? (
          <button
            onClick={() => setConfirmed(true)}
            className="w-full py-3 rounded-xl bg-red-500 text-white text-sm font-semibold active:bg-red-600"
          >
            Delete Division
          </button>
        ) : (
          <div className="space-y-2">
            <p className="text-xs text-center text-red-600 font-semibold">Are you sure?</p>
            <div className="flex gap-2">
              <button
                onClick={handleDelete}
                className="flex-1 py-3 rounded-xl bg-red-600 text-white text-sm font-bold active:bg-red-700"
              >
                Yes, delete
              </button>
              <button
                onClick={() => setConfirmed(false)}
                className="flex-1 py-3 rounded-xl bg-gray-100 text-slate-500 text-sm font-semibold active:bg-gray-200"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main Manage Page ─────────────────────────────────────────

const menuItems: { flow: Flow; icon: string; iconBg: string; title: string; subtitle: string; section: "club" | "players" | "matches" | "divisions" }[] = [
  { flow: "club-name", icon: "🏑", iconBg: "bg-pitch-50", title: "Club Name", subtitle: "Shown in the header", section: "club" },
  { flow: "instagram", icon: "📷", iconBg: "bg-pink-50", title: "Instagram", subtitle: "Link to your club's page", section: "club" },
  { flow: "share", icon: "📤", iconBg: "bg-green-50", title: "Share App", subtitle: "Send the link and code to teammates", section: "club" },
  { flow: "add-player", icon: "+", iconBg: "bg-green-50 text-green-600", title: "Add Player", subtitle: "Add someone to a squad", section: "players" },
  { flow: "rename-player", icon: "✏️", iconBg: "bg-blue-50", title: "Rename Player", subtitle: "Fix a name or spelling", section: "players" },
  { flow: "remove-player", icon: "−", iconBg: "bg-red-50 text-red-500", title: "Remove Player", subtitle: "Take someone off a squad", section: "players" },
  { flow: "nominate-players", icon: "★", iconBg: "bg-amber-50 text-amber-600", title: "Nominate Players", subtitle: "Select players for a squad", section: "players" },
  { flow: "add-match", icon: "+", iconBg: "bg-green-50 text-green-600", title: "Add Match", subtitle: "New fixture to the calendar", section: "matches" },
  { flow: "remove-match", icon: "−", iconBg: "bg-red-50 text-red-500", title: "Remove Match", subtitle: "Delete a fixture", section: "matches" },
  { flow: "add-division", icon: "+", iconBg: "bg-green-50 text-green-600", title: "Add Division", subtitle: "Add another division", section: "divisions" },
  { flow: "edit-division", icon: "⚙️", iconBg: "bg-slate-50", title: "Edit Division", subtitle: "Update name, league, season", section: "divisions" },
  { flow: "delete-division", icon: "−", iconBg: "bg-red-50 text-red-500", title: "Delete Division", subtitle: "Permanently remove a division", section: "divisions" },
];

// Flows that need a division picker first
const flowsNeedingDivision: Flow[] = [
  "add-player",
  "rename-player",
  "remove-player",
  "nominate-players",
  "add-match",
  "remove-match",
  "edit-division",
  "delete-division",
];

// Labels for the division picker per flow
const divisionPickerLabels: Record<string, { title: string; subtitle: string }> = {
  "add-player": { title: "Add Player", subtitle: "Which division?" },
  "rename-player": { title: "Rename Player", subtitle: "Which division?" },
  "remove-player": { title: "Remove Player", subtitle: "Which division?" },
  "nominate-players": { title: "Nominate Players", subtitle: "Which division?" },
  "add-match": { title: "Add Match", subtitle: "Which division?" },
  "remove-match": { title: "Remove Match", subtitle: "Which division?" },
  "edit-division": { title: "Edit Division", subtitle: "Which division?" },
  "delete-division": { title: "Delete Division", subtitle: "Which division?" },
};

export default function ManagePage() {
  const router = useRouter();
  const [flow, setFlow] = useState<Flow>(null);
  const [flowTeamId, setFlowTeamId] = useState<string | null>(null);
  const [teams, setTeamsList] = useState<Team[]>([]);
  const [newTeamDiv, setNewTeamDiv] = useState("");
  const [mounted, setMounted] = useState(false);

  const refresh = useCallback(() => {
    setTeamsList(getTeams());
  }, []);

  useEffect(() => {
    refresh();
    setMounted(true);
    // Redirect players away — they shouldn't be here
    if (!isAdmin()) {
      router.replace("/");
    }
  }, [refresh, router]);

  // Re-render when Firestore syncs new data from other users
  useEffect(() => {
    const onSync = () => refresh();
    window.addEventListener("firestore-sync", onSync);
    return () => window.removeEventListener("firestore-sync", onSync);
  }, [refresh]);

  const handleFlowDone = () => {
    // If we're in a sub-flow, go back to division picker
    // If in division picker, go back to menu
    if (flowTeamId) {
      setFlowTeamId(null);
    } else {
      setFlow(null);
    }
    refresh();
  };

  const handleBackToMenu = () => {
    setFlow(null);
    setFlowTeamId(null);
    refresh();
  };

  const handleDivisionPick = (teamId: string) => {
    if (flow === "add-match") {
      // Set active team then navigate to create page
      setActiveTeamId(teamId);
      router.push("/create");
      return;
    }
    setFlowTeamId(teamId);
  };

  // Auto-pick division when only one team exists (via effect, not during render)
  useEffect(() => {
    if (flow && flowsNeedingDivision.includes(flow) && !flowTeamId && teams.length === 1) {
      if (flow === "add-match") {
        setActiveTeamId(teams[0].id);
        router.push("/create");
      } else {
        setFlowTeamId(teams[0].id);
      }
    }
  }, [flow, flowTeamId, teams, router]);

  const handleAddDivision = () => {
    if (newTeamDiv.trim()) {
      const active = getActiveTeam();
      addTeam({
        name: active.name,
        shortName: active.shortName,
        division: newTeamDiv.trim(),
        league: active.league,
        season: active.season,
      });
      setNewTeamDiv("");
      setFlow(null);
      refresh();
    }
  };

  if (!mounted) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="w-6 h-6 border-2 border-pitch-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // ── Add Division (no picker needed) ──────────────────────
  if (flow === "add-division") {
    return (
      <div className="animate-fade-in">
        <BackButton onBack={handleBackToMenu} />
        <h2 className="text-lg font-bold text-slate-900 mb-1">Add Division</h2>
        <p className="text-sm text-slate-400 mb-4">Add another division to your club</p>
        <div className="flex gap-2">
          <input
            autoFocus
            type="text"
            value={newTeamDiv}
            onChange={(e) => setNewTeamDiv(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAddDivision()}
            placeholder="e.g. Women's Division 3"
            className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none text-sm"
          />
          <button
            onClick={handleAddDivision}
            disabled={!newTeamDiv.trim()}
            className="px-5 py-3 rounded-xl bg-pitch-600 text-white text-sm font-semibold disabled:opacity-30 active:bg-pitch-700"
          >
            Add
          </button>
        </div>

        {teams.length > 0 && (
          <div className="mt-6">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Existing divisions
            </p>
            <div className="flex flex-wrap gap-1.5">
              {teams.map((t) => (
                <span key={t.id} className="text-xs bg-gray-100 text-slate-500 px-2.5 py-1 rounded-full font-medium">
                  {t.division}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── Club Name (no picker needed) ──────────────────────────
  if (flow === "club-name") {
    return <ClubNameFlow onDone={handleBackToMenu} />;
  }

  // ── Instagram (no picker needed) ─────────────────────────
  if (flow === "instagram") {
    return <InstagramFlow onDone={handleBackToMenu} />;
  }

  // ── Share (no picker needed) ────────────────────────────
  if (flow === "share") {
    return <ShareFlow onDone={handleBackToMenu} />;
  }

  // ── Division picker step (for flows that need it) ────────
  if (flow && flowsNeedingDivision.includes(flow) && !flowTeamId) {
    // Single-team auto-pick is handled by useEffect above
    if (teams.length === 1) return null;

    const labels = divisionPickerLabels[flow] ?? { title: "Select Division", subtitle: "Which division?" };
    return (
      <DivisionPicker
        title={labels.title}
        subtitle={labels.subtitle}
        teams={teams}
        onPick={handleDivisionPick}
        onBack={handleBackToMenu}
      />
    );
  }

  // ── Sub-flows (division already picked) ──────────────────
  if (flow && flowTeamId) {
    const props = { teamId: flowTeamId, teams, onDone: handleFlowDone };
    switch (flow) {
      case "add-player": return <AddPlayerFlow {...props} />;
      case "rename-player": return <RenamePlayerFlow {...props} />;
      case "remove-player": return <RemovePlayerFlow {...props} />;
      case "nominate-players": return <NominatePlayersFlow {...props} />;
      case "remove-match": return <RemoveMatchFlow {...props} />;
      case "edit-division": return <EditDivisionFlow {...props} />;
      case "delete-division": return <DeleteDivisionFlow {...props} onDeleted={handleBackToMenu} />;
      default: return null;
    }
  }

  // ── Main menu ────────────────────────────────────────────
  const sections = [
    { key: "club" as const, label: "Club" },
    { key: "players" as const, label: "Players" },
    { key: "matches" as const, label: "Matches" },
    { key: "divisions" as const, label: "Divisions" },
  ];

  return (
    <div className="animate-fade-in">
      <h2 className="text-lg font-bold text-slate-900 mb-4">Manage</h2>

      <div className="space-y-6">
        {sections.map((section) => (
          <div key={section.key}>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 px-1">
              {section.label}
            </h3>
            <div className="bg-white rounded-2xl shadow-card overflow-hidden divide-y divide-gray-50">
              {menuItems
                .filter((item) => item.section === section.key)
                .map((item) => (
                  <button
                    key={item.flow}
                    onClick={() => { setFlow(item.flow); setFlowTeamId(null); }}
                    className="w-full flex items-center gap-4 px-4 py-4 active:bg-gray-50 transition-colors text-left"
                  >
                    <div className={`w-10 h-10 rounded-xl ${item.iconBg} flex items-center justify-center text-lg font-bold shrink-0`}>
                      {item.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800">{item.title}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{item.subtitle}</p>
                    </div>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 shrink-0">
                      <polyline points="9 18 15 12 9 6" />
                    </svg>
                  </button>
                ))}
            </div>
          </div>
        ))}
      </div>

      {/* Reset & Log out */}
      <div className="mt-8 mb-4 space-y-2">
        <button
          onClick={async () => {
            if (confirm("Reset all data? This clears any changes and reloads the original rosters and fixtures. Availability responses will be empty.")) {
              await resetData();
              window.location.reload();
            }
          }}
          className="w-full text-center text-xs font-semibold text-red-400 active:text-red-600 py-3"
        >
          Reset All Data
        </button>
      </div>
    </div>
  );
}
