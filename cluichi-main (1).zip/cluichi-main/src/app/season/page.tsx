"use client";

import FixturePlanner from "@/components/FixturePlanner";

export default function SeasonPage() {
  return (
    <div className="-mx-4">
      <FixturePlanner />
    </div>
  );
}
