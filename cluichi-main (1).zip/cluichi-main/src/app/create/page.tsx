"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { EventType, HomeAway } from "@/lib/types";
import { addEvent, getTeams, getActiveTeamId } from "@/lib/store";

const eventTypes: { value: EventType; label: string; emoji: string }[] = [
  { value: "match", label: "Match", emoji: "📅" },
  { value: "training", label: "Training", emoji: "🏃" },
  { value: "other", label: "Other", emoji: "📋" },
];

const homeAwayOptions: { value: HomeAway; label: string }[] = [
  { value: "H", label: "Home" },
  { value: "A", label: "Away" },
  { value: null, label: "N/A" },
];

export default function CreateEvent() {
  const router = useRouter();
  const [type, setType] = useState<EventType>("match");
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");
  const [opponent, setOpponent] = useState("");
  const [opponentShort, setOpponentShort] = useState("");
  const [homeAway, setHomeAway] = useState<HomeAway>("H");
  const [notes, setNotes] = useState("");
  const [teamId, setTeamId] = useState("");
  const [teams, setTeams] = useState<{ id: string; name: string; division: string }[]>([]);

  useEffect(() => {
    const allTeams = getTeams();
    setTeams(allTeams.map((t) => ({ id: t.id, name: t.name, division: t.division })));
    setTeamId(getActiveTeamId());
  }, []);

  const isValid = title.trim() && date;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid) return;

    addEvent({
      title: title.trim(),
      type,
      date,
      time: time || "TBC",
      location: location.trim() || "TBC",
      opponent: type === "match" ? opponent.trim() || undefined : undefined,
      opponentShort: type === "match" ? opponentShort.trim() || undefined : undefined,
      homeAway: type === "match" ? homeAway : null,
      notes: notes.trim() || undefined,
      teamId,
    });

    router.push("/");
  };

  // Auto-generate short name from opponent
  const handleOpponentChange = (val: string) => {
    setOpponent(val);
    if (!opponentShort || opponentShort === opponent.slice(0, 3).toUpperCase()) {
      setOpponentShort(val.slice(0, 3).toUpperCase());
    }
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-lg font-bold text-slate-900 mb-4">New Event</h2>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Team selector (if multiple teams) */}
        {teams.length > 1 && (
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
              Team
            </label>
            <select
              value={teamId}
              onChange={(e) => setTeamId(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 focus:border-pitch-500 focus:outline-none transition-colors text-sm"
            >
              {teams.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} — {t.division}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Event type selector */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 block">
            Type
          </label>
          <div className="flex gap-2">
            {eventTypes.map((et) => (
              <button
                key={et.value}
                type="button"
                onClick={() => {
                  setType(et.value);
                  if (et.value === "training" && !title) setTitle("Training");
                }}
                className={`flex-1 py-2.5 rounded-xl border-2 text-sm font-semibold transition-all duration-150 ${
                  type === et.value
                    ? "border-pitch-500 bg-pitch-50 text-pitch-700"
                    : "border-gray-200 bg-white text-slate-500"
                }`}
              >
                {et.emoji} {et.label}
              </button>
            ))}
          </div>
        </div>

        {/* Title */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
            Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={type === "match" ? "vs Opponent Name" : "Training"}
            className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none transition-colors text-sm"
          />
        </div>

        {/* Opponent + Short + Home/Away (only for matches) */}
        {type === "match" && (
          <div className="space-y-3 animate-fade-in">
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
                  Opponent
                </label>
                <input
                  type="text"
                  value={opponent}
                  onChange={(e) => handleOpponentChange(e.target.value)}
                  placeholder="Castletown"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none transition-colors text-sm"
                />
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
                  Short
                </label>
                <input
                  type="text"
                  value={opponentShort}
                  onChange={(e) => setOpponentShort(e.target.value.toUpperCase().slice(0, 4))}
                  placeholder="CAS"
                  maxLength={4}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none transition-colors text-sm text-center uppercase font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 block">
                Home / Away
              </label>
              <div className="flex gap-2">
                {homeAwayOptions.map((opt) => (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => setHomeAway(opt.value)}
                    className={`flex-1 py-2.5 rounded-xl border-2 text-sm font-semibold transition-all ${
                      homeAway === opt.value
                        ? "border-pitch-500 bg-pitch-50 text-pitch-700"
                        : "border-gray-200 bg-white text-slate-500"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Date & Time row */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
              Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 focus:border-pitch-500 focus:outline-none transition-colors text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
              Time <span className="normal-case tracking-normal font-normal">(optional)</span>
            </label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 focus:border-pitch-500 focus:outline-none transition-colors text-sm"
            />
          </div>
        </div>

        {/* Location */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
            Location <span className="normal-case tracking-normal font-normal">(optional)</span>
          </label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Club Grounds"
            className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none transition-colors text-sm"
          />
        </div>

        {/* Notes */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5 block">
            Notes <span className="normal-case tracking-normal font-normal">(optional)</span>
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Be there 30 mins early, bring gumshield..."
            rows={3}
            className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 bg-white text-slate-900 placeholder:text-slate-300 focus:border-pitch-500 focus:outline-none transition-colors text-sm resize-none"
          />
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={!isValid}
          className={`w-full py-3.5 rounded-xl font-semibold text-base transition-all duration-150 active:animate-press ${
            isValid
              ? "bg-pitch-600 text-white shadow-md active:bg-pitch-700"
              : "bg-gray-100 text-slate-300 cursor-not-allowed"
          }`}
        >
          Create Event
        </button>
      </form>
    </div>
  );
}
