"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import { GameEvent, EventResponse, AvailabilityStatus, HomeAway } from "@/lib/types";
import { getEvent, getResponses, getMyResponse, setAvailability, updateEvent, removeEvent } from "@/lib/store";
import AvailabilityPicker from "@/components/AvailabilityPicker";
import RosterList from "@/components/RosterList";

function formatFullDate(dateStr: string): string {
  const date = new Date(dateStr + "T00:00:00");
  return date.toLocaleDateString("en-IE", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function formatTime(time: string): string {
  if (!time || !time.includes(":")) return time || "TBD";
  const [h, m] = time.split(":");
  const hour = parseInt(h);
  if (isNaN(hour)) return time;
  const ampm = hour >= 12 ? "pm" : "am";
  const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
  return `${displayHour}:${m} ${ampm}`;
}

function EventTypeLabel({ type }: { type: GameEvent["type"] }) {
  const config = {
    match: { emoji: "📅", label: "Match", bg: "bg-pitch-50 text-pitch-700" },
    training: { emoji: "🏃", label: "Training", bg: "bg-blue-50 text-blue-700" },
    other: { emoji: "📋", label: "Event", bg: "bg-purple-50 text-purple-700" },
  };
  const c = config[type];
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${c.bg}`}>
      {c.emoji} {c.label}
    </span>
  );
}

export default function EventDetail() {
  const params = useParams();
  const router = useRouter();
  const eventId = params.id as string;

  const [event, setEventData] = useState<GameEvent | undefined>();
  const [responses, setResponses] = useState<EventResponse[]>([]);
  const [myStatus, setMyStatus] = useState<AvailabilityStatus>(null);
  const [mounted, setMounted] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editField, setEditField] = useState<string | null>(null);
  const [tempValue, setTempValue] = useState("");
  const [showDelete, setShowDelete] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(() => {
    setEventData(getEvent(eventId));
    setResponses(getResponses(eventId));
    setMyStatus(getMyResponse(eventId));
  }, [eventId]);

  useEffect(() => {
    refresh();
    setMounted(true);
  }, [refresh]);

  // Re-render when Firestore syncs new data from other users
  useEffect(() => {
    const onSync = () => refresh();
    window.addEventListener("firestore-sync", onSync);
    return () => window.removeEventListener("firestore-sync", onSync);
  }, [refresh]);

  useEffect(() => {
    if (inputRef.current) inputRef.current.focus();
  }, [editField]);

  const handleAvailability = (status: AvailabilityStatus) => {
    setAvailability(eventId, status);
    refresh();
  };

  const startEdit = (field: string, value: string) => {
    setEditField(field);
    setTempValue(value);
  };

  const saveField = () => {
    if (editField && event && tempValue.trim()) {
      updateEvent(eventId, { [editField]: tempValue.trim() });
      refresh();
    }
    setEditField(null);
    setTempValue("");
  };

  const handleDelete = async () => {
    await removeEvent(eventId);
    router.push("/");
  };

  const toggleHomeAway = () => {
    if (!event) return;
    const cycle: (HomeAway)[] = ["H", "A", null];
    const currentIdx = cycle.indexOf(event.homeAway ?? null);
    const next = cycle[(currentIdx + 1) % cycle.length];
    updateEvent(eventId, { homeAway: next });
    refresh();
  };

  if (!mounted) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="w-6 h-6 border-2 border-pitch-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-16">
        <p className="text-4xl mb-3">🤔</p>
        <p className="text-slate-500 font-medium">Event not found</p>
        <button onClick={() => router.push("/")} className="mt-3 text-pitch-600 font-medium text-sm">
          ← Back to home
        </button>
      </div>
    );
  }

  const EditableField = ({ field, value, icon, className = "" }: { field: string; value: string; icon: string; className?: string }) => {
    if (editMode && editField === field) {
      return (
        <div className="flex items-center gap-2.5">
          <span className="text-base">{icon}</span>
          <input
            ref={inputRef}
            type={field === "date" ? "date" : field === "time" ? "time" : "text"}
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            onBlur={saveField}
            onKeyDown={(e) => e.key === "Enter" && saveField()}
            className="flex-1 text-sm text-slate-600 border-b-2 border-pitch-500 outline-none bg-transparent py-0.5"
          />
        </div>
      );
    }
    return (
      <div
        className={`flex items-center gap-2.5 text-slate-600 ${editMode ? "cursor-pointer active:opacity-60" : ""} ${className}`}
        onClick={() => editMode && startEdit(field, value)}
      >
        <span className="text-base">{icon}</span>
        <span className="text-sm">{field === "date" ? formatFullDate(value) : field === "time" ? formatTime(value) : value}</span>
        {editMode && (
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 ml-auto shrink-0">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
          </svg>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Top bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="flex items-center gap-1 text-sm font-medium text-slate-500 active:text-slate-700 -ml-1"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back
        </button>
        <button
          onClick={() => {
            setEditMode(!editMode);
            setEditField(null);
            setShowDelete(false);
          }}
          className={`text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors ${
            editMode
              ? "bg-pitch-600 text-white"
              : "bg-gray-100 text-slate-500 active:bg-gray-200"
          }`}
        >
          {editMode ? "Done" : "Edit"}
        </button>
      </div>

      {/* Event header */}
      <div className="bg-white rounded-2xl shadow-card p-5">
        <div className="flex items-start justify-between mb-3">
          {editMode && editField === "title" ? (
            <input
              ref={inputRef}
              type="text"
              value={tempValue}
              onChange={(e) => setTempValue(e.target.value)}
              onBlur={saveField}
              onKeyDown={(e) => e.key === "Enter" && saveField()}
              className="text-xl font-bold text-slate-900 border-b-2 border-pitch-500 outline-none bg-transparent flex-1 mr-2"
            />
          ) : (
            <h2
              className={`text-xl font-bold text-slate-900 ${editMode ? "cursor-pointer active:opacity-60" : ""}`}
              onClick={() => editMode && startEdit("title", event.title)}
            >
              {event.title}
            </h2>
          )}
          <div className="flex items-center gap-2 shrink-0">
            {(event.homeAway || editMode) && (
              <button
                onClick={() => editMode && toggleHomeAway()}
                className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  event.homeAway === "H"
                    ? "bg-pitch-50 text-pitch-700"
                    : event.homeAway === "A"
                    ? "bg-slate-100 text-slate-500"
                    : "bg-gray-100 text-slate-400"
                } ${editMode ? "active:opacity-60" : ""}`}
              >
                {event.homeAway === "H" ? "HOME" : event.homeAway === "A" ? "AWAY" : "N/A"}
              </button>
            )}
            <EventTypeLabel type={event.type} />
          </div>
        </div>

        <div className="space-y-2.5">
          <EditableField field="date" value={event.date} icon="📅" />
          <EditableField field="time" value={event.time} icon="🕐" />
          <EditableField field="location" value={event.location} icon="📍" />
          {(event.opponent || editMode) && (
            <EditableField field="opponent" value={event.opponent || ""} icon="🆚" />
          )}
        </div>

        {/* Notes */}
        {editMode && editField === "notes" ? (
          <div className="mt-4">
            <textarea
              autoFocus
              value={tempValue}
              onChange={(e) => setTempValue(e.target.value)}
              onBlur={() => {
                if (event) updateEvent(eventId, { notes: tempValue.trim() || undefined });
                refresh();
                setEditField(null);
              }}
              rows={3}
              className="w-full text-sm p-3 rounded-xl border-2 border-pitch-500 outline-none resize-none"
              placeholder="Add notes..."
            />
          </div>
        ) : event.notes ? (
          <div
            className={`mt-4 p-3 bg-amber-50 rounded-xl border border-amber-100 ${editMode ? "cursor-pointer active:opacity-60" : ""}`}
            onClick={() => editMode && startEdit("notes", event.notes || "")}
          >
            <p className="text-sm text-amber-800">📝 {event.notes}</p>
          </div>
        ) : editMode ? (
          <button
            onClick={() => startEdit("notes", "")}
            className="mt-4 text-xs text-slate-400 font-medium active:text-slate-600"
          >
            + Add notes
          </button>
        ) : null}

        {/* Delete event */}
        {editMode && (
          <div className="mt-5 pt-4 border-t border-gray-100">
            {showDelete ? (
              <div className="flex items-center gap-2 animate-fade-in">
                <span className="text-sm text-red-500">Delete this event?</span>
                <button
                  onClick={handleDelete}
                  className="px-3 py-1.5 rounded-lg bg-red-500 text-white text-sm font-semibold"
                >
                  Yes, delete
                </button>
                <button
                  onClick={() => setShowDelete(false)}
                  className="px-3 py-1.5 rounded-lg bg-gray-100 text-slate-500 text-sm"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowDelete(true)}
                className="text-sm text-red-400 font-medium active:text-red-600"
              >
                🗑️ Delete event
              </button>
            )}
          </div>
        )}
      </div>

      {/* Roster */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 px-1">
          Responses
        </h3>
        <RosterList responses={responses} teamId={event.teamId} />
      </div>
    </div>
  );
}
